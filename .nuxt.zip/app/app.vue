<template>
    <AppPreloader />
    <NuxtPage />
</template>
